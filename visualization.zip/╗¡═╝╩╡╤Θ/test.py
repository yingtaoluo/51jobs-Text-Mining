import matplotlib.pyplot as plt
import numpy as np
from scipy import optimize


A, B = 
print (A)
print (B)