from pylab import *
mpl.rcParams['font.sans-serif'] = ['SimHei']  #提供汉字支持
rect=plt.bar(left = (0,1),height = (1,0.5),width=0.35, align='center')
plt.ylabel(u'人数')  # 显示汉字，前面u前导，代表使用unicode
plt.xlabel(u'性别')
plt.xticks((0,1),(u"男",u"女"))
plt.legend((rect,),(u"图例",))
plt.show()
