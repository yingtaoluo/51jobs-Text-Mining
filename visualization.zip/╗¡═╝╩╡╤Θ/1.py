# 引用
import matplotlib.pyplot as plt
import numpy as np
from scipy import optimize
import math

#直线方程函数
def f(x, A, B):
    return A*x + B

# 准备数据
x = [0, 0.0803, 0.1596, 0.2389, 0.321, 0.404, 0.489, 0.556, 0.641, 0.724, 0.81]
y = [0, 2.614, 5.24, 7.86, 10.48, 13.1, 15.72, 18.34, 20.96, 23.58, 26.2]
# 绘图
plt.scatter(x[:],y[:],25,"red")

#直线拟合
A, B = optimize.curve_fit(f, x, y)[0]
x1 = np.arange(0, 1, 0.01)
y1 = A * x1 + B
plt.plot(x1, y1, 'blue')

plt.title('The relationship between B and the polarization angle')
plt.xlabel('intensity of magnetization B/T')
plt.ylabel('Polarization angle˚')
#print("拟合直线方程为：y=",A,"x+",B)

n = len(x)
uncertainty = 0
for i in range (0, n-1):
    uncertainty += abs(x[i] * A + B - y[i])**2
t = math.sqrt(uncertainty/(n-1))
#print("拟合方法的A类不确定度为：",t)

# 显示
#plt.show()
