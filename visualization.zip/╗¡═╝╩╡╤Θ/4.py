from pylab import *
import numpy as np
n=100
x=np.random.normal(0,1,n)
y=np.random.normal(0,1,n)
scatter(x,y)
show()
