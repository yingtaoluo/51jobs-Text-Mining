# 引用
import matplotlib.pyplot as plt
import numpy as np

# 准备数据
x = np.arange(-5, 5, 0.1)
y = x**2
# 设置横坐标范围
plt.xlim(-5, 5)
plt.ylim(0, 100)
# 设置横轴标识
plt.xlabel('x')
plt.ylabel('y=x*x')
# 设置图形的标题
plt.title("image")
# 绘图
plt.plot(x, y, 'r')
# 显示
plt.show()

