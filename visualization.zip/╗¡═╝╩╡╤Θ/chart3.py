# 3D图
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
# 生成横纵坐标 -5 到5 步长为0.25
X = np.arange(-5, 5, 0.25)
Y = np.arange(-5, 5, 0.25)
# 用于生成网格
X, Y = np.meshgrid(X, Y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)
# 创建一个绘图对象
fig = plt.figure()
# 创建一个Axes对象
ax = Axes3D(fig)
# 绘制图
ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.viridis)

plt.show()