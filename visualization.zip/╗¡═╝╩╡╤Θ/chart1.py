# 点图 和线图
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

# 通过rcParams设置全局横纵轴字体大小
mpl.rcParams['xtick.labelsize'] = 18
mpl.rcParams['ytick.labelsize'] = 18

np.random.seed(42)
# x轴的采样点,y轴采样点
x = np.linspace(0, 5, 100)
y = 2*np.sinc(x) + 0.3*x**2
y_data = y+np.random.normal(scale=0.3, size=100)
# 指定图表名称
plt.figure('data')
# 采用散点图 ，图形用.
plt.plot(x, y_data, '.')

# plt.scatter(x,y)
plt.show()

plt.figure('model')
plt.plot(x, y)
plt.show()

