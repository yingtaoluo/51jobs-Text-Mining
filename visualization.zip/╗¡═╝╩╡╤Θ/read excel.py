from openpyxl import load_workbook
import matplotlib.pyplot as plt

#读取路径
book = load_workbook(filename="C:\\Users\\罗颖韬\\Desktop\\物理实验\\1.xlsx")
#读取名字为Sheet1的表
sheet = book.get_sheet_by_name("Sheet1")
#用于存储数据的数组
data0= []
data1= []
data2= []
data3= []
data4= []
data5= []
row_num = 1
while row_num <= 500 :
    #将表中第一列的1-100行数据写入data数组中
    data0.append(sheet.cell(row=row_num, column=1).value)
    data1.append(sheet.cell(row=row_num, column=2).value)
    data1[row_num-1] = float(data1[row_num-1])
    data2.append(sheet.cell(row=row_num, column=3).value)
    data3.append(sheet.cell(row=row_num, column=4).value)
    data4.append(sheet.cell(row=row_num, column=5).value)
    data5.append(sheet.cell(row=row_num, column=6).value)
    row_num = row_num + 1

l1 = plt.plot(data0, data1, color = "red")
l2 = plt.plot(data0, data2, color = "yellow")
l3 = plt.plot(data0, data3, color = "green")
l4 = plt.plot(data0, data4, color = "blue")
l5 = plt.plot(data0, data5, color = "purple")
plt.legend(handles = [l1, l2, l3, l4, l5], labels = ['1', '2', '3', '4', '5'])
plt.xlabel('Length of waves(nm)')
plt.ylabel('T(%)')
plt.show()